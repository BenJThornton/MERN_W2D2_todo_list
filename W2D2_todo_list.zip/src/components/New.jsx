import React, {useState} from 'react'

const New = (props) =>{

    const [newItemName, setNewItemName] = useState("")

    const submitItem = (e) => {
        e.preventDefault();
        const newItem = {
            itemName : newItemName,
            status: false
        }

        props.createItem(newItem);
    }

    return(
        <div>
            <form onSubmit={submitItem}>
                <input type="text" onChange={e=> setNewItemName(e.target.value)} value={newItemName}/>
                <button>Add</button>
            </form>
            <hr />
        </div>
    )
}

export default New