import React from 'react';

const Item = (props) =>{
    const {item} = props;

    return(
        <div style={{

            height: "50px",
            width: "400px",
            borderWidth: "2px",
            borderColor: "darkblue",
            borderStyle: "solid",
            textDecoration: item.status ? "line-through" : "" 
            }}>
            {item.itemName}
            {item.status ? "Done!" : ""}
            <input type="checkbox" checked={item.status} onChange={()=> props.updateStatus(props.index)}/>
            <button onClick={()=>props.deleteItem(props.index)}>Delete</button>
        </div>
    )
}

export default Item;