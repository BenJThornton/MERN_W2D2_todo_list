import './App.css';
import Item from './components/Item';
import New from './components/New';
import React, {useState} from 'react'

function App() {
  const [items, setItems] = useState(
    [{itemName: "Example", status: false}]
  )

  //CREATE
  const createItem = (newItemObj) => {
    
    setItems([...items, newItemObj])
  }

  //DELETE
  const deleteItem = (itemIndex) =>{
    const filteredItems = items.filter( (item, i) =>{
      if(i !== itemIndex){
        return true;
      }else{
        return false;
      }
    });

    setItems(filteredItems);
  }

  //UPDATE
  const updateStatus = (idx) =>{
    const copyItems = [...items];
    if(copyItems[idx].status === true){
      copyItems[idx].status = false;
    }else{
      copyItems[idx].status = true;
    }
    setItems(copyItems);
  }

  return (
    <div className="App">
      <h1>To-Do List</h1>
      <hr />
      <New createItem={createItem}/>
      {
        items.map((item, idx) => {
          return <Item 
            item={item} 
            key={idx}
            index={idx}
            deleteItem={deleteItem}
            updateStatus={updateStatus}
            />
        })
      }
    </div>
  );
}

export default App;

